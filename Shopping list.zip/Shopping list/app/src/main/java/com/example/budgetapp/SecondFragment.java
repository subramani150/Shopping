//package com.example.budgetapp;
//
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.navigation.fragment.NavHostFragment;
//
//import com.example.budgetapp.databinding.FragmentSecondBinding;
//
//public class SecondFragment extends Fragment {
//
//    private FragmentSecondBinding binding;
//
//    @Override
//    public View onCreateView(
//            LayoutInflater inflater, ViewGroup container,
//            Bundle savedInstanceState
//    ) {
//
//        binding = FragmentSecondBinding.inflate(inflater, container, false);
//        return binding.getRoot();
//
//    }
//
//    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//        binding.buttonSecond.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                NavHostFragment.findNavController(SecondFragment.this)
//                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
//            }
//        });
//    }
//
//    @Override
//    public void onDestroyView() {
//        super.onDestroyView();
//        binding = null;
//    }
//
//}

package com.example.budgetapp;

        import android.os.Bundle;
        import android.view.View;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.ListView;
        import android.widget.Toast;

        import androidx.appcompat.app.AppCompatActivity;

        import java.util.ArrayList;

public class SecondFragment extends AppCompatActivity {

    EditText entryName, entryAmount;
    Button addEntryButton;
    ListView budgetListView;
    ArrayList<String> budgetList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_second);

        // Initialize UI elements
        entryName = findViewById(R.id.entryName);
        entryAmount = findViewById(R.id.entryAmount);
        addEntryButton = findViewById(R.id.addEntryButton);
        budgetListView = findViewById(R.id.budgetListView);

        // Initialize the list and adapter
        budgetList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, budgetList);
        budgetListView.setAdapter(adapter);

        // Set OnClickListener for the Add Entry button
        addEntryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get input data
                String name = entryName.getText().toString().trim();
                String amountString = entryAmount.getText().toString().trim();

                if (name.isEmpty() || amountString.isEmpty()) {
                    Toast.makeText(SecondFragment.this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Parse the amount
                //double amount = Double.parseDouble(amountString);

                // Create an entry and add it to the list
                String entry = name + " - " + amountString;
                budgetList.add(entry);

                // Notify the adapter to update the ListView
                adapter.notifyDataSetChanged();

                // Clear the input fields
                entryName.setText("");
                entryAmount.setText("");
            }
        });
    }
}
